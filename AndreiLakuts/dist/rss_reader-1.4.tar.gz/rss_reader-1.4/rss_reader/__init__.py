from rss_reader.rss_reader import RssParser, main_program
